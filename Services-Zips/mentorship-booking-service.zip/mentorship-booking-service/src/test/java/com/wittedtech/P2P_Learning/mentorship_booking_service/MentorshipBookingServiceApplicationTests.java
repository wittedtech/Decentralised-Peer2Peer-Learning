package com.wittedtech.P2P_Learning.mentorship_booking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorshipBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
