package com.wittedtech.P2P_Learning.gamification_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
