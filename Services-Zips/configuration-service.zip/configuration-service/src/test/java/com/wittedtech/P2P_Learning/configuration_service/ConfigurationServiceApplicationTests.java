package com.wittedtech.P2P_Learning.configuration_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
