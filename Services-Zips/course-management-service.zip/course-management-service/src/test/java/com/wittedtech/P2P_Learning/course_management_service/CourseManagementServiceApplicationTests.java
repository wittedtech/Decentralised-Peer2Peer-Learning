package com.wittedtech.P2P_Learning.course_management_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
