package com.wittedtech.P2P_Learning.logging_and_monitoring_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggingAndMonitoringServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
