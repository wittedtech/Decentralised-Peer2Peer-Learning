package com.wittedtech.P2P_Learning.logging_and_monitoring_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoggingAndMonitoringServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoggingAndMonitoringServiceApplication.class, args);
	}

}
