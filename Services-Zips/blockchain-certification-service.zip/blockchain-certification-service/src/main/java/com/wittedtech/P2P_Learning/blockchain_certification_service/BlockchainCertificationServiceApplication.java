package com.wittedtech.P2P_Learning.blockchain_certification_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockchainCertificationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockchainCertificationServiceApplication.class, args);
	}

}
