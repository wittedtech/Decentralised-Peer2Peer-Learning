package com.wittedtech.P2P_Learning.blockchain_certification_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockchainCertificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
